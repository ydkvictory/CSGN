import numpy as np
import matplotlib.pyplot as plt
import os


# 假设 ROC 数据文件存储在指定的文件夹中
folder_path = '../ROC curve and AUC value/ROC/'
proteins = []
fpr_list = []
tpr_list = []


# AUC 值和蛋白质名称
auc_values = [
    0.9925, 0.9229, 0.9560, 0.9737, 0.8743,
    0.9387, 0.9069, 0.8861, 0.8614, 0.8306,
    0.8261, 0.9329, 0.9842, 0.9942, 0.9598,
    0.8828
]
protein_names = [
    "AUF1", "DGCR8", "EWSR1", "HNRNPC", "MOV10",
    "TDP43", "FMRP", "HUR", "IGF2BP1", "PTB",
    "IGF2BP3", "U2AF65", "PUM2", "TAF15", "FXR2",
    "LIN28A"
]

# 创建字典
auc_dict = dict(zip(protein_names, auc_values))

# # 测试字典
# print(auc_dict)


# 遍历文件夹中的所有 .txt 文件
for filename in os.listdir(folder_path):
    if filename.endswith('.txt'):
        # 读取数据
        data = np.loadtxt(os.path.join(folder_path, filename))
        fpr = data[:, 0]  # 第一列为 fpr
        tpr = data[:, 1]  # 第二列为 tpr

        # 添加到列表
        fpr_list.append(fpr)
        tpr_list.append(tpr)

        # 提取 AUC 值
        protein = filename.split('(')[0]
        proteins.append(protein)

# 创建 ROC 图
plt.figure(figsize=(10, 8))

# 绘制每个数据集的 ROC 曲线
for i in range(len(proteins)):
    plt.plot(fpr_list[i], tpr_list[i], label=f'{proteins[i]} (AUC = {auc_dict[proteins[i]]:.4f})')

# 设置图形标题和标签
plt.title('ROC Curves for Datasets')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.xlim([0.0, 1.05])
plt.ylim([0.0, 1.05])

# 绘制对角线（随机猜测的基线）
plt.plot([0, 1], [0, 1], 'k--', label='Random Guess')

# 显示图例
plt.legend(loc='lower right')

# 保存图像
plt.savefig('roc_curves.jpeg', dpi=600, format='jpeg')

# 显示图像
plt.show()
