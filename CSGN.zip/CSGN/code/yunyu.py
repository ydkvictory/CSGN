import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import ptitprince as pt

# 假设你有六种模型在16个数据集上的AUC值
auc_data = np.array([
    [0.85, 0.88, 0.90, 0.87, 0.89, 0.91, 0.85, 0.90, 0.92, 0.93, 0.88, 0.89, 0.91, 0.92, 0.85, 0.88],
    [0.80, 0.82, 0.84, 0.81, 0.83, 0.85, 0.80, 0.84, 0.86, 0.87, 0.82, 0.83, 0.85, 0.86, 0.80, 0.82],
    [0.78, 0.80, 0.82, 0.79, 0.81, 0.83, 0.78, 0.82, 0.84, 0.85, 0.80, 0.81, 0.83, 0.84, 0.78, 0.80],
    [0.88, 0.89, 0.91, 0.88, 0.90, 0.92, 0.88, 0.91, 0.93, 0.94, 0.89, 0.90, 0.92, 0.93, 0.88, 0.89],
    [0.82, 0.84, 0.86, 0.83, 0.85, 0.87, 0.82, 0.86, 0.88, 0.89, 0.84, 0.85, 0.87, 0.88, 0.82, 0.84],
    [0.79, 0.81, 0.83, 0.80, 0.82, 0.84, 0.79, 0.83, 0.85, 0.86, 0.81, 0.82, 0.84, 0.85, 0.79, 0.81]
])

# 模型名称
models = [f"Model {i+1}" for i in range(6)]

# 将数据转换为 pandas DataFrame，方便作图
data = pd.DataFrame(auc_data.T, columns=models)
data = data.melt(var_name='Model', value_name='AUC')

# 设置绘图风格
sns.set(style="whitegrid", font_scale=1.2)

# 创建 Raincloud Plot
f, ax = plt.subplots(figsize=(8, 6))
pt.RainCloud(x="Model", y="AUC", data=data, palette="Set2", bw=.2, width_viol=.6, ax=ax, orient="h", alpha=.65, dodge=True)

# 显示图形
plt.title("Raincloud Plot of AUC for Different Models")
plt.show()
